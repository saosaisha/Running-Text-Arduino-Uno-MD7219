var indexSectionsWithContent =
{
  0: "abcdgmprsuxy~",
  1: "m",
  2: "m",
  3: "bcdgmsu~",
  4: "r",
  5: "r",
  6: "cmpxy",
  7: "acrs"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "enums",
  5: "enumvalues",
  6: "defines",
  7: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Enumerations",
  5: "Enumerator",
  6: "Macros",
  7: "Pages"
};

