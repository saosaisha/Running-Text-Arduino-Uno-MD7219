var searchData=
[
  ['max_5fzones',['MAX_ZONES',['../_m_d___parola_8h.html#a3c8ce1beff274980c5636aa8a3811cdc',1,'MD_Parola.h']]]
];
